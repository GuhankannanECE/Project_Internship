export default {
  template: `
    <div class="card mb-4" :class="{ 'text-muted': !modelTrained }">
      <div class="card-header bg-success text-white">
        <h4 class="mb-0">Cavity Tuning</h4>
      </div>
      <div class="card-body">
        <div v-if="!modelTrained" class="alert alert-warning">
          Please train the model first before tuning the resonator.
        </div>
        
        <form @submit.prevent="tuneResonator">
          <div class="mb-3">
            <label for="target_freq" class="form-label">Target Frequency (GHz)</label>
            <input type="number" class="form-control" id="target_freq" v-model="target_freq" 
                   step="0.1" min="1" max="5" :disabled="!modelTrained">
            <div class="form-text">Target frequency in GHz (typically 1-5 GHz range)</div>
          </div>
          <div class="mb-3">
            <label for="target_q" class="form-label">Target Q Factor</label>
            <input type="number" class="form-control" id="target_q" v-model="target_q" 
                   step="100" min="100" max="50000" :disabled="!modelTrained">
            <div class="form-text">Quality factor (Q) typically ranges from hundreds to tens of thousands</div>
          </div>
          <div class="mb-3">
            <label for="iterations" class="form-label">Max Iterations</label>
            <input type="number" class="form-control" id="iterations" v-model="iterations" 
                   min="10" max="1000" :disabled="!modelTrained">
            <div class="form-text">More iterations may improve results but take longer to compute</div>
          </div>
          <button type="submit" class="btn btn-success" :disabled="!modelTrained || isTuning">
            <span v-if="isTuning">
              <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
              Tuning...
            </span>
            <span v-else>Tune Resonator</span>
          </button>
        </form>
      </div>
    </div>
  `,
  props: {
    modelTrained: Boolean,
    isTuning: Boolean
  },
  data() {
    return {
      target_freq: 2.4,
      target_q: 10000,  // Updated default to a more realistic value
      iterations: 100
    }
  },
  methods: {
    tuneResonator() {
      this.$emit('tune', { 
        target_freq: this.target_freq, 
        target_q: this.target_q, 
        iterations: this.iterations 
      });
    }
  }
}
