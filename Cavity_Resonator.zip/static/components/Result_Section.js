export default {
  template: `
    <div v-if="tuningCompleted" class="card mb-4 shadow">
      <div class="card-header bg-info text-white">
        <h4 class="mb-0">Optimization Results</h4>
      </div>
      <div class="card-body">
        <div class="row mb-4">
          <div class="col-md-6">
            <h5>Optimal Parameters</h5>
            <table class="table table-striped">
              <thead class="table-light">
                <tr>
                  <th>Parameter</th>
                  <th>Value</th>
                </tr>
              </thead>
              <tbody>
                <tr v-if="results.optimal_params">
                  <td><strong>Length</strong></td>
                  <td>{{ (results.optimal_params[0] * 100).toFixed(2) }} cm</td>
                </tr>
                <tr v-if="results.optimal_params">
                  <td><strong>Width</strong></td>
                  <td>{{ (results.optimal_params[1] * 100).toFixed(2) }} cm</td>
                </tr>
                <tr v-if="results.optimal_params">
                  <td><strong>Height</strong></td>
                  <td>{{ (results.optimal_params[2] * 100).toFixed(2) }} cm</td>
                </tr>
                <tr v-if="results.optimal_params">
                  <td><strong>Conductivity</strong></td>
                  <td>{{ (results.optimal_params[3] / 1e6).toFixed(2) }} MS/m</td>
                </tr>
                <tr v-if="results.optimal_params">
                  <td><strong>Surface Roughness</strong></td>
                  <td>{{ (results.optimal_params[4] * 1e6).toFixed(2) }} μm</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="col-md-6">
            <h5>Predicted Performance</h5>
            <table class="table table-striped">
              <thead class="table-light">
                <tr>
                  <th>Metric</th>
                  <th>Target</th>
                  <th>Achieved</th>
                  <th>Difference</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>Resonant Frequency</strong></td>
                  <td>{{ targetValues.target_freq }} GHz</td>
                  <td>{{ results.resonant_frequency.toFixed(4) }} GHz</td>
                  <td :class="getDifferenceClass(results.resonant_frequency, targetValues.target_freq)">
                    {{ ((results.resonant_frequency - targetValues.target_freq) / targetValues.target_freq * 100).toFixed(2) }}%
                  </td>
                </tr>
                <tr>
                  <td><strong>Quality Factor</strong></td>
                  <td>{{ targetValues.target_q.toLocaleString() }}</td>
                  <td>{{ results.quality_factor.toLocaleString(undefined, {maximumFractionDigits: 0}) }}</td>
                  <td :class="getDifferenceClass(results.quality_factor, targetValues.target_q)">
                    {{ ((results.quality_factor - targetValues.target_q) / targetValues.target_q * 100).toFixed(2) }}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <h5>Optimization Progress</h5>
        <img :src="'data:image/png;base64,' + results.optimization_plot" class="img-fluid mb-4 border rounded" alt="Optimization plot">
        
        <h5>Final Results</h5>
        <img :src="'data:image/png;base64,' + results.final_results_plot" class="img-fluid border rounded" alt="Final results plot">
      </div>
      <div class="card-footer">
        <button 
          class="btn btn-primary" 
          @click="$emit('download-pdf')">
          <i class="fas fa-file-pdf"></i> Download Results as PDF
        </button>
        <button 
          class="btn btn-outline-secondary ms-2" 
          @click="copyToClipboard">
          <i class="fas fa-copy"></i> Copy Results to Clipboard
        </button>
      </div>
    </div>
  `,
  props: {
    tuningCompleted: Boolean,
    results: Object,
    targetValues: Object
  },
  methods: {
    getDifferenceClass(achieved, target) {
      const percentDiff = Math.abs((achieved - target) / target * 100);
      if (percentDiff < 1) return 'text-success fw-bold';
      if (percentDiff < 5) return 'text-warning';
      return 'text-danger';
    },
    copyToClipboard() {
      // Format results as text
      const text = `
CAVITY RESONATOR TUNING RESULTS
===============================
Target Frequency: ${this.targetValues.target_freq} GHz
Achieved Frequency: ${this.results.resonant_frequency.toFixed(4)} GHz
Difference: ${((this.results.resonant_frequency - this.targetValues.target_freq) / this.targetValues.target_freq * 100).toFixed(2)}%

Target Q Factor: ${this.targetValues.target_q}
Achieved Q Factor: ${this.results.quality_factor.toFixed(1)}
Difference: ${((this.results.quality_factor - this.targetValues.target_q) / this.targetValues.target_q * 100).toFixed(2)}%

OPTIMAL PARAMETERS
=================
Length: ${(this.results.optimal_params[0] * 100).toFixed(2)} cm
Width: ${(this.results.optimal_params[1] * 100).toFixed(2)} cm
Height: ${(this.results.optimal_params[2] * 100).toFixed(2)} cm
Conductivity: ${(this.results.optimal_params[3] / 1e6).toFixed(2)} MS/m
Surface Roughness: ${(this.results.optimal_params[4] * 1e6).toFixed(2)} μm
      `;
      
      // Copy to clipboard
      navigator.clipboard.writeText(text)
        .then(() => alert('Results copied to clipboard!'))
        .catch(err => console.error('Failed to copy: ', err));
    }
  }
}
