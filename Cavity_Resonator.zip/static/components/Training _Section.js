export default {
  template: `
    <div class="card mb-4 shadow">
      <div class="card-header bg-primary text-white">
        <h4 class="mb-0">Cavity Resonator Model Training</h4>
      </div>
      <div class="card-body">
        <form @submit.prevent="trainModel">
          <div class="mb-3">
            <label for="samples" class="form-label">Number of Training Samples</label>
            <input type="number" class="form-control" id="samples" v-model="samples" min="1000" max="50000">
            <div class="form-text">More samples provide better accuracy but take longer to train.</div>
          </div>
          <button type="submit" class="btn btn-primary" :disabled="isTraining">
            <span v-if="isTraining">
              <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
              Training...
            </span>
            <span v-else>Train Neural Network Model</span>
          </button>
        </form>
            
        <div v-if="modelTrained" class="mt-4">
          <div class="alert alert-success">
            <strong>Model successfully trained!</strong> 
            <p class="mb-0">Model accuracy score: {{ modelScore.toFixed(4) }}</p>
            <p class="mb-0">Average frequency: {{ meanFreq.toFixed(2) }} GHz</p>
            <p class="mb-0">Average Q factor: {{ Math.round(meanQ).toLocaleString() }}</p>
          </div>
          <div class="mt-3">
            <h5>Model Performance Visualization</h5>
            <img :src="'data:image/png;base64,' + modelPlot" class="img-fluid border rounded" alt="Model performance plot">
            <div class="form-text text-center">Left: Frequency prediction accuracy | Right: Q-factor prediction accuracy</div>
          </div>
        </div>
      </div>
    </div>
  `,
  props: {
    modelTrained: Boolean,
    modelScore: Number,
    modelPlot: String,
    meanFreq: Number,  // Ensure this prop is properly passed
    meanQ: Number,     // Ensure this prop is properly passed
    isTraining: Boolean
  },
  data() {
    return {
      samples: 5000
    }
  },
  methods: {
    trainModel() {
      this.$emit('train', { samples: this.samples });
    }
  }
}
