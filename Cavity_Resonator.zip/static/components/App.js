import TrainingSection from './Training _Section.js';  // Fixed filename
import TuningSection from './Tuning_Section.js';      // Fixed filename
import ResultsSection from './Result_Section.js';    // Fixed filename
const { jsPDF } = window.jspdf;

export default {
  components: {
    TrainingSection,
    TuningSection,
    ResultsSection
  },
  template: `
    <div class="container mt-4">
      <div class="text-center mb-4">
        <h1 class="display-4">Cavity Resonator ML Tuning</h1>
        <p class="lead">Optimize cavity resonator parameters using machine learning</p>
      </div>

      <TrainingSection 
        :model-trained="modelTrained"
        :model-score="modelScore"
        :model-plot="modelPlot"
        :is-training="isTraining"
        :mean-freq="meanFreq"    // Added missing prop
        :mean-q="meanQ"          // Added missing prop
        @train="trainModel"
      />
      
      <TuningSection
        :model-trained="modelTrained"
        :is-tuning="isTuning"
        @tune="tuneResonator"
      />
      
      <ResultsSection
        :tuning-completed="tuningCompleted"
        :results="tuneResults"
        :target-values="targetValues"
        @download-pdf="downloadPDF" 
      />
    </div>
  `,
  data() {
    return {
      isTraining: false,
      isTuning: false,
      modelTrained: false,
      modelScore: 0,
      modelPlot: null,
      meanFreq: 0,        // Added missing data property
      meanQ: 0,           // Added missing data property
      tuningCompleted: false,
      tuneResults: {},
      targetValues: {
        target_freq: 0,
        target_q: 0
      }
    };
  },
  methods: {
    async trainModel(params) {
      this.isTraining = true;
      
      const formData = new FormData();
      formData.append('samples', params.samples);
      
      try {
        const response = await fetch('/train', {
          method: 'POST',
          body: formData
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
          this.modelTrained = true;
          this.modelScore = result.test_score;
          this.modelPlot = result.model_plot;
          this.meanFreq = result.mean_freq;  // Store mean frequency from API
          this.meanQ = result.mean_q;        // Store mean Q factor from API
        } else {
          alert('Error training model: ' + result.message);
        }
      } catch (err) {
        alert('Error: ' + err.message);
      } finally {
        this.isTraining = false;
      }
    },
    
    async tuneResonator(params) {
      console.log('Tuning resonator with params:', params); // Debugging
      this.isTuning = true;
      this.targetValues = params;
    
      const formData = new FormData();
      formData.append('target_freq', params.target_freq);
      formData.append('target_q', params.target_q);
      formData.append('iterations', params.iterations);
    
      try {
        const response = await fetch('/tune', {
          method: 'POST',
          body: formData
        });
    
        const result = await response.json();
        console.log('Tuning response:', result); // Debugging
    
        if (result.status === 'success') {
          this.tuningCompleted = true;
          this.tuneResults = result;
        } else {
          alert('Error tuning resonator: ' + result.message);
        }
      } catch (err) {
        alert('Error: ' + err.message);
      } finally {
        this.isTuning = false;
      }
    },

    downloadPDF() {
      const doc = new jsPDF();
      
      // Add title and header
      doc.setFontSize(20);
      doc.text('Cavity Resonator Tuning Results', 105, 20, { align: 'center' });
      
      // Add date
      doc.setFontSize(10);
      doc.text(`Generated on: ${new Date().toLocaleString()}`, 105, 30, { align: 'center' });
      
      // Target and achieved values
      doc.setFontSize(14);
      doc.text('Target vs Achieved Performance', 20, 45);
      
      doc.setFontSize(12);
      doc.text(`Target Frequency: ${this.targetValues.target_freq} GHz`, 20, 55);
      doc.text(`Achieved Frequency: ${this.tuneResults.resonant_frequency.toFixed(4)} GHz`, 20, 65);
      doc.text(`Frequency Difference: ${((this.tuneResults.resonant_frequency - this.targetValues.target_freq) / this.targetValues.target_freq * 100).toFixed(2)}%`, 20, 75);
      
      doc.text(`Target Q-Factor: ${this.targetValues.target_q}`, 20, 90);
      doc.text(`Achieved Q-Factor: ${this.tuneResults.quality_factor.toFixed(1)}`, 20, 100);
      doc.text(`Q-Factor Difference: ${((this.tuneResults.quality_factor - this.targetValues.target_q) / this.targetValues.target_q * 100).toFixed(2)}%`, 20, 110);
      
      // Optimal parameters
      doc.setFontSize(14);
      doc.text('Optimal Cavity Parameters', 20, 130);
      
      doc.setFontSize(12);
      if (this.tuneResults.optimal_params) {
        doc.text(`Length: ${(this.tuneResults.optimal_params[0] * 100).toFixed(2)} cm`, 20, 140);
        doc.text(`Width: ${(this.tuneResults.optimal_params[1] * 100).toFixed(2)} cm`, 20, 150);
        doc.text(`Height: ${(this.tuneResults.optimal_params[2] * 100).toFixed(2)} cm`, 20, 160);
        doc.text(`Conductivity: ${(this.tuneResults.optimal_params[3] / 1e6).toFixed(2)} MS/m`, 20, 170);
        doc.text(`Surface Roughness: ${(this.tuneResults.optimal_params[4] * 1e6).toFixed(2)} μm`, 20, 180);
      }
      
      // Add plots if they exist
      if (this.tuneResults.optimization_plot) {
        doc.addPage();
        doc.setFontSize(14);
        doc.text('Optimization Progress', 105, 20, { align: 'center' });
        doc.addImage('data:image/png;base64,' + this.tuneResults.optimization_plot, 'PNG', 15, 30, 180, 100);
      }
      
      if (this.tuneResults.final_results_plot) {
        doc.addPage();
        doc.setFontSize(14);
        doc.text('Final Results', 105, 20, { align: 'center' });
        doc.addImage('data:image/png;base64,' + this.tuneResults.final_results_plot, 'PNG', 15, 30, 180, 100);
      }

      doc.save('Cavity_Resonator_Results.pdf');
    }
  }
};
