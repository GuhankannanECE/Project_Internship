import { createApp } from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';
import App from './components/App.js';

const app = createApp(App);
app.mount('#app');